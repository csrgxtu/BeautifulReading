[IPython auto reload your module](https://ipython.org/ipython-doc/dev/config/extensions/autoreload.html)  
```bash
%load_ext autoreload
%autoreload 2
```

[Python guide org json](http://docs.python-guide.org/en/latest/scenarios/json/)  
[json – JavaScript Object Notation Serializer](https://pymotw.com/2/json/)  
