#!/usr/bin/python
string = '我的'
print string
