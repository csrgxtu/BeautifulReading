[Python MySQL Database Access](http://www.tutorialspoint.com/python/python_database_access.htm)  [Virtual Environments](http://docs.python-guide.org/en/latest/dev/virtualenvs/)  
[BeautifulSoup4 docs](http://www.crummy.com/software/BeautifulSoup/bs4/doc/#installing-beautiful-soup)  
sudo apt-get install python-dev
