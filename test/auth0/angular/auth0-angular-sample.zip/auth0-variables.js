var AUTH0_CLIENT_ID='AFRZV4NudbDz0SDFT4qHUhKzDzbHZbti'; 
var AUTH0_DOMAIN='csrgxtu.auth0.com'; 
var AUTH0_CALLBACK_URL=location.href;