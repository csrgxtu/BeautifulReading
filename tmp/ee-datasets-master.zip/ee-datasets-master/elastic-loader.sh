#!/bin/sh
/usr/bin/env java -jar elastic-loader.jar $1 $2
